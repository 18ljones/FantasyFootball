import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class MainController implements Initializable {

	@FXML
	private TextField weekNumberField;
	
	@FXML
	private Label totalTeamPoints;
	
	// all player QB tab table view columns
	@FXML
	private Tab APQBTab;

	@FXML
	private TableView<OFF> tableViewQB;
	@FXML
	private TableColumn<OFF, String> nameQB;
	@FXML
	private TableColumn<OFF, String> opponentQB;
	@FXML
	private TableColumn<OFF, String> statusQB;
	@FXML
	private TableColumn<OFF, String> catchAttemptsQB;
	@FXML
	private TableColumn<OFF, String> passYardsQB;
	@FXML
	private TableColumn<OFF, String> passTdsQB;
	@FXML
	private TableColumn<OFF, String> interceptionsQB;
	@FXML
	private TableColumn<OFF, String> rushQB;
	@FXML
	private TableColumn<OFF, String> rushYardsQB;
	@FXML
	private TableColumn<OFF, String> rushTdsQB;
	@FXML
	private TableColumn<OFF, String> receptionsQB;
	@FXML
	private TableColumn<OFF, String> receivingYardsQB;
	@FXML
	private TableColumn<OFF, String> receivingTdsQB;
	@FXML
	private TableColumn<OFF, String> receivingTargetsQB;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsQB;
	@FXML
	private TableColumn<OFF, String> fumblesQB;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsQB;
	@FXML
	private TableColumn<OFF, String> pointsQB;

	// all player RB tab table view columns
	@FXML
	private Tab APRBTab;

	@FXML
	private TableView<OFF> tableViewRB;
	@FXML
	private TableColumn<OFF, String> nameRB;
	@FXML
	private TableColumn<OFF, String> opponentRB;
	@FXML
	private TableColumn<OFF, String> statusRB;
	@FXML
	private TableColumn<OFF, String> catchAttemptsRB;
	@FXML
	private TableColumn<OFF, String> passYardsRB;
	@FXML
	private TableColumn<OFF, String> passTdsRB;
	@FXML
	private TableColumn<OFF, String> interceptionsRB;
	@FXML
	private TableColumn<OFF, String> rushRB;
	@FXML
	private TableColumn<OFF, String> rushYardsRB;
	@FXML
	private TableColumn<OFF, String> rushTdsRB;
	@FXML
	private TableColumn<OFF, String> receptionsRB;
	@FXML
	private TableColumn<OFF, String> receivingYardsRB;
	@FXML
	private TableColumn<OFF, String> receivingTdsRB;
	@FXML
	private TableColumn<OFF, String> receivingTargetsRB;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsRB;
	@FXML
	private TableColumn<OFF, String> fumblesRB;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsRB;
	@FXML
	private TableColumn<OFF, String> pointsRB;

	// all player QB tab table view columns
	@FXML
	private Tab APWRTab;

	@FXML
	private TableView<OFF> tableViewWR;
	@FXML
	private TableColumn<OFF, String> nameWR;
	@FXML
	private TableColumn<OFF, String> opponentWR;
	@FXML
	private TableColumn<OFF, String> statusWR;
	@FXML
	private TableColumn<OFF, String> catchAttemptsWR;
	@FXML
	private TableColumn<OFF, String> passYardsWR;
	@FXML
	private TableColumn<OFF, String> passTdsWR;
	@FXML
	private TableColumn<OFF, String> interceptionsWR;
	@FXML
	private TableColumn<OFF, String> rushWR;
	@FXML
	private TableColumn<OFF, String> rushYardsWR;
	@FXML
	private TableColumn<OFF, String> rushTdsWR;
	@FXML
	private TableColumn<OFF, String> receptionsWR;
	@FXML
	private TableColumn<OFF, String> receivingYardsWR;
	@FXML
	private TableColumn<OFF, String> receivingTdsWR;
	@FXML
	private TableColumn<OFF, String> receivingTargetsWR;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsWR;
	@FXML
	private TableColumn<OFF, String> fumblesWR;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsWR;
	@FXML
	private TableColumn<OFF, String> pointsWR;

	// all player TE tab table view columns
	@FXML
	private Tab APTETab;

	@FXML
	private TableView<OFF> tableViewTE;
	@FXML
	private TableColumn<OFF, String> nameTE;
	@FXML
	private TableColumn<OFF, String> opponentTE;
	@FXML
	private TableColumn<OFF, String> statusTE;
	@FXML
	private TableColumn<OFF, String> catchAttemptsTE;
	@FXML
	private TableColumn<OFF, String> passYardsTE;
	@FXML
	private TableColumn<OFF, String> passTdsTE;
	@FXML
	private TableColumn<OFF, String> interceptionsTE;
	@FXML
	private TableColumn<OFF, String> rushTE;
	@FXML
	private TableColumn<OFF, String> rushYardsTE;
	@FXML
	private TableColumn<OFF, String> rushTdsTE;
	@FXML
	private TableColumn<OFF, String> receptionsTE;
	@FXML
	private TableColumn<OFF, String> receivingYardsTE;
	@FXML
	private TableColumn<OFF, String> receivingTdsTE;
	@FXML
	private TableColumn<OFF, String> receivingTargetsTE;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsTE;
	@FXML
	private TableColumn<OFF, String> fumblesTE;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsTE;
	@FXML
	private TableColumn<OFF, String> pointsTE;

	// all player DST tab table view columns
	@FXML
	private Tab APDSTTab;

	@FXML
	private TableView<DST> tableViewDST;

	@FXML
	private TableColumn<DST, String> nameDST;
	@FXML
	private TableColumn<DST, String> opponentDST;
	@FXML
	private TableColumn<DST, String> statusDST;
	@FXML
	private TableColumn<DST, String> touchdownsDST;
	@FXML
	private TableColumn<DST, String> interceptionsDST;
	@FXML
	private TableColumn<DST, String> fumblesRecoveredDST;
	@FXML
	private TableColumn<DST, String> sacksDST;
	@FXML
	private TableColumn<DST, String> safetiesDST;
	@FXML
	private TableColumn<DST, String> blocksDST;
	@FXML
	private TableColumn<DST, String> pointsAllowedDST;
	@FXML
	private TableColumn<DST, String> pointsDST;

	// all player K tab table view columns
	@FXML
	private Tab APKTab;

	@FXML
	private TableView<KICK> tableViewK;

	@FXML
	private TableColumn<KICK, String> name;
	@FXML
	private TableColumn<KICK, String> opponent;
	@FXML
	private TableColumn<KICK, String> status;
	@FXML
	private TableColumn<KICK, String> thirtynine;
	@FXML
	private TableColumn<KICK, String> fortynine;
	@FXML
	private TableColumn<KICK, String> fifty;
	@FXML
	private TableColumn<KICK, String> totalTries;
	@FXML
	private TableColumn<KICK, String> extraPoints;
	@FXML
	private TableColumn<KICK, String> pts;
	
	// My Team QB tab table view columns
	@FXML
	private Tab QBTabMT;

	@FXML
	private TableView<OFF> tableViewQBMT;
	@FXML
	private TableColumn<OFF, String> nameQBMT;
	@FXML
	private TableColumn<OFF, String> opponentQBMT;
	@FXML
	private TableColumn<OFF, String> statusQBMT;
	@FXML
	private TableColumn<OFF, String> catchAttemptsQBMT;
	@FXML
	private TableColumn<OFF, String> passYardsQBMT;
	@FXML
	private TableColumn<OFF, String> passTdsQBMT;
	@FXML
	private TableColumn<OFF, String> interceptionsQBMT;
	@FXML
	private TableColumn<OFF, String> rushQBMT;
	@FXML
	private TableColumn<OFF, String> rushYardsQBMT;
	@FXML
	private TableColumn<OFF, String> rushTdsQBMT;
	@FXML
	private TableColumn<OFF, String> receptionsQBMT;
	@FXML
	private TableColumn<OFF, String> receivingYardsQBMT;
	@FXML
	private TableColumn<OFF, String> receivingTdsQBMT;
	@FXML
	private TableColumn<OFF, String> receivingTargetsQBMT;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsQBMT;
	@FXML
	private TableColumn<OFF, String> fumblesQBMT;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsQBMT;
	@FXML
	private TableColumn<OFF, String> pointsQBMT;

	// My Team RB tab table view columns
	@FXML
	private Tab RBTabMT;

	@FXML
	private TableView<OFF> tableViewRBMT;
	@FXML
	private TableColumn<OFF, String> nameRBMT;
	@FXML
	private TableColumn<OFF, String> opponentRBMT;
	@FXML
	private TableColumn<OFF, String> statusRBMT;
	@FXML
	private TableColumn<OFF, String> catchAttemptsRBMT;
	@FXML
	private TableColumn<OFF, String> passYardsRBMT;
	@FXML
	private TableColumn<OFF, String> passTdsRBMT;
	@FXML
	private TableColumn<OFF, String> interceptionsRBMT;
	@FXML
	private TableColumn<OFF, String> rushRBMT;
	@FXML
	private TableColumn<OFF, String> rushYardsRBMT;
	@FXML
	private TableColumn<OFF, String> rushTdsRBMT;
	@FXML
	private TableColumn<OFF, String> receptionsRBMT;
	@FXML
	private TableColumn<OFF, String> receivingYardsRBMT;
	@FXML
	private TableColumn<OFF, String> receivingTdsRBMT;
	@FXML
	private TableColumn<OFF, String> receivingTargetsRBMT;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsRBMT;
	@FXML
	private TableColumn<OFF, String> fumblesRBMT;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsRBMT;
	@FXML
	private TableColumn<OFF, String> pointsRBMT;

	// My Team WR tab table view columns
	@FXML
	private Tab WRTabMT;

	@FXML
	private TableView<OFF> tableViewWRMT;
	@FXML
	private TableColumn<OFF, String> nameWRMT;
	@FXML
	private TableColumn<OFF, String> opponentWRMT;
	@FXML
	private TableColumn<OFF, String> statusWRMT;
	@FXML
	private TableColumn<OFF, String> catchAttemptsWRMT;
	@FXML
	private TableColumn<OFF, String> passYardsWRMT;
	@FXML
	private TableColumn<OFF, String> passTdsWRMT;
	@FXML
	private TableColumn<OFF, String> interceptionsWRMT;
	@FXML
	private TableColumn<OFF, String> rushWRMT;
	@FXML
	private TableColumn<OFF, String> rushYardsWRMT;
	@FXML
	private TableColumn<OFF, String> rushTdsWRMT;
	@FXML
	private TableColumn<OFF, String> receptionsWRMT;
	@FXML
	private TableColumn<OFF, String> receivingYardsWRMT;
	@FXML
	private TableColumn<OFF, String> receivingTdsWRMT;
	@FXML
	private TableColumn<OFF, String> receivingTargetsWRMT;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsWRMT;
	@FXML
	private TableColumn<OFF, String> fumblesWRMT;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsWRMT;
	@FXML
	private TableColumn<OFF, String> pointsWRMT;

	// My Team TE tab table view columns
	@FXML
	private Tab TETabMT;

	@FXML
	private TableView<OFF> tableViewTEMT;
	@FXML
	private TableColumn<OFF, String> nameTEMT;
	@FXML
	private TableColumn<OFF, String> opponentTEMT;
	@FXML
	private TableColumn<OFF, String> statusTEMT;
	@FXML
	private TableColumn<OFF, String> catchAttemptsTEMT;
	@FXML
	private TableColumn<OFF, String> passYardsTEMT;
	@FXML
	private TableColumn<OFF, String> passTdsTEMT;
	@FXML
	private TableColumn<OFF, String> interceptionsTEMT;
	@FXML
	private TableColumn<OFF, String> rushTEMT;
	@FXML
	private TableColumn<OFF, String> rushYardsTEMT;
	@FXML
	private TableColumn<OFF, String> rushTdsTEMT;
	@FXML
	private TableColumn<OFF, String> receptionsTEMT;
	@FXML
	private TableColumn<OFF, String> receivingYardsTEMT;
	@FXML
	private TableColumn<OFF, String> receivingTdsTEMT;
	@FXML
	private TableColumn<OFF, String> receivingTargetsTEMT;
	@FXML
	private TableColumn<OFF, String> twoPointConversionsTEMT;
	@FXML
	private TableColumn<OFF, String> fumblesTEMT;
	@FXML
	private TableColumn<OFF, String> miscellaneousTdsTEMT;
	@FXML
	private TableColumn<OFF, String> pointsTEMT;

	// My Team DST tab table view columns
	@FXML
	private Tab DSTTabMT;

	@FXML
	private TableView<DST> tableViewDSTMT;

	@FXML
	private TableColumn<DST, String> nameDSTMT;
	@FXML
	private TableColumn<DST, String> opponentDSTMT;
	@FXML
	private TableColumn<DST, String> statusDSTMT;
	@FXML
	private TableColumn<DST, String> touchdownsDSTMT;
	@FXML
	private TableColumn<DST, String> interceptionsDSTMT;
	@FXML
	private TableColumn<DST, String> fumblesRecoveredDSTMT;
	@FXML
	private TableColumn<DST, String> sacksDSTMT;
	@FXML
	private TableColumn<DST, String> safetiesDSTMT;
	@FXML
	private TableColumn<DST, String> blocksDSTMT;
	@FXML
	private TableColumn<DST, String> pointsAllowedDSTMT;
	@FXML
	private TableColumn<DST, String> pointsDSTMT;

	// My Team K tab table view columns
	@FXML
	private Tab KTabMT;

	@FXML
	private TableView<KICK> tableViewKMT;

	@FXML
	private TableColumn<KICK, String> nameMT;
	@FXML
	private TableColumn<KICK, String> opponentMT;
	@FXML
	private TableColumn<KICK, String> statusMT;
	@FXML
	private TableColumn<KICK, String> thirtynineMT;
	@FXML
	private TableColumn<KICK, String> fortynineMT;
	@FXML
	private TableColumn<KICK, String> fiftyMT;
	@FXML
	private TableColumn<KICK, String> totalTriesMT;
	@FXML
	private TableColumn<KICK, String> extraPointsMT;
	@FXML
	private TableColumn<KICK, String> ptsMT;

	public void loadPlayerButtonPressed() throws IOException {
		try {
			int temp = Integer.parseInt(weekNumberField.getText());
			String week = weekNumberField.getText();
			JSoupRun.genTextFile("all players.txt", week);
			Scanner input = new Scanner(new File("all players.txt"));
			String line = input.nextLine();
			while (!line.equals("")) {
				OFF playerOFF = new OFF(line);
				tableViewQB.getItems().add(playerOFF);
				line = input.nextLine();
			}
			line = input.nextLine();
			while (!line.equals("")) {
				OFF playerOFF = new OFF(line);
				tableViewRB.getItems().add(playerOFF);
				line = input.nextLine();
			}
			line = input.nextLine();
			while (!line.equals("")) {
				OFF playerOFF = new OFF(line);
				tableViewWR.getItems().add(playerOFF);
				line = input.nextLine();
			}
			line = input.nextLine();
			while (!line.equals("")) {
				OFF playerOFF = new OFF(line);
				tableViewTE.getItems().add(playerOFF);
				line = input.nextLine();
			}
			line = input.nextLine();
			while (!line.equals("")) {
				DST playerDST = new DST(line);
				tableViewDST.getItems().add(playerDST);
				line = input.nextLine();
			}
			line = input.nextLine();
			while (input.hasNextLine()) {
				KICK playerKICK = new KICK(line);
				tableViewK.getItems().add(playerKICK);
				line = input.nextLine();
			}
			input.close();
		}
		catch(NumberFormatException ex) {
			Alert error = new Alert(AlertType.INFORMATION);
			error.setTitle("ERROR");
			error.setHeaderText(null);
			error.setContentText("Must enter an integer for the week number!");

			error.showAndWait();
		}
	}
	
	public void addQBButtonPressed() {
		OFF qb = tableViewQB.getSelectionModel().getSelectedItem();
		tableViewQBMT.getItems().add(qb);
		tableViewQBMT.setVisible(false);
		tableViewQBMT.setVisible(true);
	}
	
	public void addRBButtonPressed() {
		OFF rb = tableViewRB.getSelectionModel().getSelectedItem();
		tableViewRBMT.getItems().add(rb);
		tableViewRBMT.setVisible(false);
		tableViewRBMT.setVisible(true);
	}
	
	public void addWRButtonPressed() {
		OFF wr = tableViewWR.getSelectionModel().getSelectedItem();
		tableViewWRMT.getItems().add(wr);
		tableViewWRMT.setVisible(false);
		tableViewWRMT.setVisible(true);
	}
	
	public void addTEButtonPressed() {
		OFF te = tableViewTE.getSelectionModel().getSelectedItem();
		tableViewTEMT.getItems().add(te);
		tableViewTEMT.setVisible(false);
		tableViewTEMT.setVisible(true);
	}
	public void addDSTButtonPressed() {
		DST dst = tableViewDST.getSelectionModel().getSelectedItem();
		tableViewDSTMT.getItems().add(dst);
		tableViewDSTMT.setVisible(false);
		tableViewDSTMT.setVisible(true);
	}
	public void addKButtonPressed() {
		KICK k = tableViewK.getSelectionModel().getSelectedItem();
		tableViewKMT.getItems().add(k);
		tableViewKMT.setVisible(false);
		tableViewKMT.setVisible(true);
	}
	
	public void calcTotalPointsButtonPressed() {
		double total = 0.0;
		for (OFF player : tableViewQBMT.getItems()) {
		    total = total + Double.parseDouble(player.getPoints());
		}
		for (OFF player : tableViewRBMT.getItems()) {
		    total = total + Double.parseDouble(player.getPoints());
		}
		for (OFF player : tableViewWRMT.getItems()) {
		    total = total + Double.parseDouble(player.getPoints());
		}
		for (OFF player : tableViewTEMT.getItems()) {
		    total = total + Double.parseDouble(player.getPoints());
		}
		for (DST player : tableViewDSTMT.getItems()) {
		    total = total + Double.parseDouble(player.getPoints());
		}
		for (KICK player : tableViewKMT.getItems()) {
		    total = total + Double.parseDouble(player.getPts());
		}
		
		totalTeamPoints.setText("" + total);
	}
	
	public void saveMyTeamButtonPressed() throws IOException {
		PrintWriter pw = new PrintWriter(new FileWriter("MyTeam.txt"));
		for (OFF player : tableViewQBMT.getItems()) {
		    pw.println(player);
		}
		pw.println();
		for (OFF player : tableViewRBMT.getItems()) {
			pw.println(player);
		}
		pw.println();
		for (OFF player : tableViewWRMT.getItems()) {
			pw.println(player);
		}
		pw.println();
		for (OFF player : tableViewTEMT.getItems()) {
			pw.println(player);
		}
		pw.println();
		for (DST player : tableViewDSTMT.getItems()) {
			pw.println(player);
		}
		pw.println();
		for (KICK player : tableViewKMT.getItems()) {
			pw.println(player);
		}
		pw.println("end");
		pw.close();
	}
	
	public void loadMyTeamButtonPressed() throws FileNotFoundException {
		
		tableViewQBMT.getItems().clear();
		tableViewRBMT.getItems().clear();
		tableViewWRMT.getItems().clear();
		tableViewTEMT.getItems().clear();
		tableViewDSTMT.getItems().clear();
		tableViewKMT.getItems().clear();
		Scanner input = new Scanner(new File("MyTeam.txt"));
		String line = input.nextLine();
		while (!line.equals("")) {
			OFF playerOFF = new OFF(line);
			tableViewQBMT.getItems().add(playerOFF);
			line = input.nextLine();
		}
		line = input.nextLine();
		while (!line.equals("")) {
			OFF playerOFF = new OFF(line);
			tableViewRBMT.getItems().add(playerOFF);
			line = input.nextLine();
		}
		line = input.nextLine();
		while (!line.equals("")) {
			OFF playerOFF = new OFF(line);
			tableViewWRMT.getItems().add(playerOFF);
			line = input.nextLine();
		}
		line = input.nextLine();
		while (!line.equals("")) {
			OFF playerOFF = new OFF(line);
			tableViewTEMT.getItems().add(playerOFF);
			line = input.nextLine();
		}
		line = input.nextLine();
		while (!line.equals("")) {
			DST playerDST = new DST(line);
			tableViewDSTMT.getItems().add(playerDST);
			line = input.nextLine();
		}
		line = input.nextLine();
		System.out.println(line);
		while (!line.equals("end")) {
			KICK playerKICK = new KICK(line);
			tableViewKMT.getItems().add(playerKICK);
			line = input.nextLine();
		}
		input.close();
	}
	
	public void removeQBButtonPressed() {
		OFF qb = tableViewQBMT.getSelectionModel().getSelectedItem();
		tableViewQBMT.getItems().remove(qb);
		tableViewQBMT.setVisible(false);
		tableViewQBMT.setVisible(true);
	}
	
	public void removeRBButtonPressed() {
		OFF rb = tableViewRBMT.getSelectionModel().getSelectedItem();
		tableViewRBMT.getItems().remove(rb);
		tableViewRBMT.setVisible(false);
		tableViewRBMT.setVisible(true);
	}
	
	public void removeWRButtonPressed() {
		OFF wr = tableViewWRMT.getSelectionModel().getSelectedItem();
		tableViewWRMT.getItems().remove(wr);
		tableViewWRMT.setVisible(false);
		tableViewWRMT.setVisible(true);
	}
	
	public void removeTEButtonPressed() {
		OFF te = tableViewTEMT.getSelectionModel().getSelectedItem();
		tableViewTEMT.getItems().remove(te);
		tableViewTEMT.setVisible(false);
		tableViewTEMT.setVisible(true);
	}
	public void removeDSTButtonPressed() {
		DST dst = tableViewDSTMT.getSelectionModel().getSelectedItem();
		tableViewDSTMT.getItems().remove(dst);
		tableViewDSTMT.setVisible(false);
		tableViewDSTMT.setVisible(true);
	}
	public void removeKButtonPressed() {
		KICK k = tableViewKMT.getSelectionModel().getSelectedItem();
		tableViewKMT.getItems().remove(k);
		tableViewKMT.setVisible(false);
		tableViewKMT.setVisible(true);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		nameQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsQB.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));
		

		nameRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsRB.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsWR.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsTE.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameDST.setCellValueFactory(new PropertyValueFactory<DST, String>("name"));
		opponentDST.setCellValueFactory(new PropertyValueFactory<DST, String>("opponent"));
		statusDST.setCellValueFactory(new PropertyValueFactory<DST, String>("status"));
		touchdownsDST.setCellValueFactory(new PropertyValueFactory<DST, String>("touchdowns"));
		interceptionsDST.setCellValueFactory(new PropertyValueFactory<DST, String>("interceptions"));
		fumblesRecoveredDST.setCellValueFactory(new PropertyValueFactory<DST, String>("fumblesRecovered"));
		sacksDST.setCellValueFactory(new PropertyValueFactory<DST, String>("sacks"));
		safetiesDST.setCellValueFactory(new PropertyValueFactory<DST, String>("safeties"));
		blocksDST.setCellValueFactory(new PropertyValueFactory<DST, String>("blocks"));
		pointsAllowedDST.setCellValueFactory(new PropertyValueFactory<DST, String>("pointsAllowed"));
		pointsDST.setCellValueFactory(new PropertyValueFactory<DST, String>("points"));
		
		name.setCellValueFactory(new PropertyValueFactory<KICK, String>("name"));
		opponent.setCellValueFactory(new PropertyValueFactory<KICK, String>("opponent"));
		status.setCellValueFactory(new PropertyValueFactory<KICK, String>("status"));
		thirtynine.setCellValueFactory(new PropertyValueFactory<KICK, String>("thirtynine"));
		fortynine.setCellValueFactory(new PropertyValueFactory<KICK, String>("fortynine"));
		fifty.setCellValueFactory(new PropertyValueFactory<KICK, String>("fifty"));
		totalTries.setCellValueFactory(new PropertyValueFactory<KICK, String>("totalTries"));
		extraPoints.setCellValueFactory(new PropertyValueFactory<KICK, String>("extraPoints"));
		pts.setCellValueFactory(new PropertyValueFactory<KICK, String>("pts"));
		
		nameQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsQBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));
		

		nameRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsRBMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsWRMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("name"));
		opponentTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("opponent"));
		statusTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("status"));
		catchAttemptsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("catchAttempts"));
		passYardsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passYards"));
		passTdsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("passTds"));
		interceptionsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("interceptions"));
		rushTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rush"));
		rushYardsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushYards"));
		rushTdsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("rushTds"));
		receptionsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receptions"));
		receivingYardsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingYards"));
		receivingTdsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTds"));
		receivingTargetsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("receivingTargets"));
		twoPointConversionsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("twoPointConversions"));
		fumblesTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("fumbles"));
		miscellaneousTdsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("miscellaneousTds"));
		pointsTEMT.setCellValueFactory(new PropertyValueFactory<OFF, String>("points"));

		nameDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("name"));
		opponentDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("opponent"));
		statusDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("status"));
		touchdownsDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("touchdowns"));
		interceptionsDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("interceptions"));
		fumblesRecoveredDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("fumblesRecovered"));
		sacksDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("sacks"));
		safetiesDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("safeties"));
		blocksDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("blocks"));
		pointsAllowedDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("pointsAllowed"));
		pointsDSTMT.setCellValueFactory(new PropertyValueFactory<DST, String>("points"));
		
		nameMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("name"));
		opponentMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("opponent"));
		statusMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("status"));
		thirtynineMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("thirtynine"));
		fortynineMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("fortynine"));
		fiftyMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("fifty"));
		totalTriesMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("totalTries"));
		extraPointsMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("extraPoints"));
		ptsMT.setCellValueFactory(new PropertyValueFactory<KICK, String>("pts"));
		
	}

}
