import java.io.IOException;

public class generate {

	public static void main (String[] args) throws IOException {
		
		JSoupRun.genTextFile("all players.txt", "12");
	}
}
